# TacCaseStatus

## Enum

* `OPEN` (value: `"open"`)
* `ACKNOWLEDGED` (value: `"acknowledged"`)
* `REJECTED` (value: `"rejected"`)
* `PENDING` (value: `"pending"`)
* `HELD` (value: `"held"`)
* `INPROGRESS` (value: `"inprogress"`)
* `CANCELLED` (value: `"cancelled"`)
* `CLOSED` (value: `"closed"`)
* `RESOLVED` (value: `"resolved"`)
