# InlineResponse201

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attachmentId** | **String** | The unique identifier of the uploaded attachment |  [optional]
**href** | **String** | The URL to access the uploaded attachment |  [optional]
