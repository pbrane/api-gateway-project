# Quantity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Float** | Numeric value in a given unit |  [optional]
**units** | **String** | Unit |  [optional]
