# NoteCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | **String** | Author of the note |  [optional]
**date** | [**OffsetDateTime**](OffsetDateTime.md) | Date of the note |  [optional]
**text** | **String** | Text of the note |  [optional]
