# TacCaseCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
