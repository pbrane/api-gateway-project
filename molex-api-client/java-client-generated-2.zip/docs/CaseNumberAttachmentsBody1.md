# CaseNumberAttachmentsBody1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | [**File**](File.md) |  |  [optional]
**description** | **String** | Optional description of the attachment |  [optional]
