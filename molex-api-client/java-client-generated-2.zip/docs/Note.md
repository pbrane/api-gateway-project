# Note

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Identifier of the note within its containing entity (may or may not be globally unique, depending on provider implementation) |  [optional]
